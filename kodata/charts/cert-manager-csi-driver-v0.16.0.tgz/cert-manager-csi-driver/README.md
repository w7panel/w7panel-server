# cert-manager csi-driver

<!-- see https://artifacthub.io/packages/helm/cert-manager/cert-manager-csi-driver for the rendered version -->

## Helm Values

<!-- AUTO-GENERATED -->

#### **metrics.enabled** ~ `bool`
> Default value:
> ```yaml
> true
> ```

Enable the metrics server on csi-driver pods.  
If false, the metrics server will be disabled and the other metrics fields below will be ignored.
#### **metrics.port** ~ `number`
> Default value:
> ```yaml
> 9402
> ```

The TCP port on which the metrics server will listen.
#### **metrics.podmonitor.enabled** ~ `bool`
> Default value:
> ```yaml
> false
> ```

Create a PodMonitor to add csi-driver to Prometheus if you are using Prometheus Operator. See https://prometheus-operator.dev/docs/operator/api/#monitoring.coreos.com/v1.PodMonitor
#### **metrics.podmonitor.namespace** ~ `string`

The namespace that the pod monitor should live in, defaults to the cert-manager-csi-driver namespace.

#### **metrics.podmonitor.prometheusInstance** ~ `string`
> Default value:
> ```yaml
> default
> ```

Specifies the `prometheus` label on the created PodMonitor. This is used when different Prometheus instances have label selectors matching different PodMonitors.
#### **metrics.podmonitor.interval** ~ `string`
> Default value:
> ```yaml
> 60s
> ```

The interval to scrape metrics.
#### **metrics.podmonitor.scrapeTimeout** ~ `string`
> Default value:
> ```yaml
> 30s
> ```

The timeout before a metrics scrape fails.
#### **metrics.podmonitor.labels** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Additional labels to add to the PodMonitor.
#### **metrics.podmonitor.annotations** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Additional annotations to add to the PodMonitor.
#### **metrics.podmonitor.honorLabels** ~ `bool`
> Default value:
> ```yaml
> false
> ```

Keep labels from scraped data, overriding server-side labels.
#### **metrics.podmonitor.endpointAdditionalProperties** ~ `object`
> Default value:
> ```yaml
> {}
> ```

EndpointAdditionalProperties allows setting additional properties on the endpoint such as relabelings, metricRelabelings etc.  
  
For example:

```yaml
endpointAdditionalProperties:
 relabelings:
 - action: replace
   sourceLabels:
   - __meta_kubernetes_pod_node_name
   targetLabel: instance
```



#### **imageRegistry** ~ `string`
> Default value:
> ```yaml
> quay.io
> ```

The container registry used for csi-driver images by default. This can include path prefixes (e.g. "artifactory.example.com/docker").

#### **imageNamespace** ~ `string`
> Default value:
> ```yaml
> jetstack
> ```

The repository namespace used for csi-driver images by default.  
Examples:  
- jetstack  
- cert-manager

#### **image.registry** ~ `string`

Target image registry. This value is prepended to the target image repository, if set.  
For example:

```yaml
registry: quay.io
repository: jetstack/cert-manager-csi-driver
```

Deprecated: per-component registry prefix.  
  
If set, this value is *prepended* to the image repository that the chart would otherwise render. This applies both when `image.repository` is set and when the repository is computed from  
`imageRegistry` + `imageNamespace` + `image.name`.  
  
This can produce "double registry" style references such as  
`legacy.example.io/quay.io/jetstack/...`. Prefer using the global  
`imageRegistry`/`imageNamespace` values.

#### **image.repository** ~ `string`
> Default value:
> ```yaml
> ""
> ```

Full repository override (takes precedence over `imageRegistry`, `imageNamespace`, and `image.name`).  
Example: quay.io/jetstack/cert-manager-csi-driver

#### **image.name** ~ `string`
> Default value:
> ```yaml
> cert-manager-csi-driver
> ```

The image name for the csi-driver.  
This is used (together with `imageRegistry` and `imageNamespace`) to construct the full image reference.

#### **image.tag** ~ `string`

Override the image tag to deploy by setting this variable. If no value is set, the chart's appVersion is used.

#### **image.digest** ~ `string`

Target image digest. Override any tag, if set.  
For example:

```yaml
digest: sha256:0e072dddd1f7f8fc8909a2ca6f65e76c5f0d2fcfb8be47935ae3457e8bbceb20
```

#### **image.pullPolicy** ~ `string`
> Default value:
> ```yaml
> IfNotPresent
> ```

Kubernetes imagePullPolicy on Deployment.
#### **imagePullSecrets** ~ `array`
> Default value:
> ```yaml
> []
> ```

Optional secrets used for pulling the csi-driver container image.  
  
For example:

```yaml
imagePullSecrets:
- name: secret-name
```
#### **commonLabels** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Labels to apply to all resources.
#### **nodeDriverRegistrarImage.registry** ~ `string`

Target image registry. This value is prepended to the target image repository, if set.  
For example:

```yaml
registry: registry.k8s.io
repository: sig-storage/csi-node-driver-registrar
```

Deprecated: per-component registry prefix.  
  
If set, this value is *prepended* to the image repository that the chart would otherwise render. This applies both when `image.repository` is set and when the repository is computed from  
`imageRegistry` + `imageNamespace` + `image.name`.  
  
This can produce "double registry" style references such as  
`legacy.example.io/quay.io/jetstack/...`. Prefer using the global  
`imageRegistry`/`imageNamespace` values.

#### **nodeDriverRegistrarImage.repository** ~ `string`
> Default value:
> ```yaml
> ""
> ```

Full repository override (takes precedence over `imageRegistry`, `imageNamespace`, and `image.name`).  
Example: quay.io/jetstack/cert-manager-csi-driver

#### **nodeDriverRegistrarImage.name** ~ `string`
> Default value:
> ```yaml
> csi-node-driver-registrar
> ```

The image name for the node-driver-registrar.  
This is used to construct the full image reference if `repository` is empty.

#### **nodeDriverRegistrarImage.tag** ~ `string`

Override the image tag to deploy by setting this variable. If no value is set, the chart's appVersion is used.

#### **nodeDriverRegistrarImage.digest** ~ `string`

Target image digest. Override any tag, if set.  
For example:

```yaml
digest: sha256:0e072dddd1f7f8fc8909a2ca6f65e76c5f0d2fcfb8be47935ae3457e8bbceb20
```

#### **nodeDriverRegistrarImage.pullPolicy** ~ `string`
> Default value:
> ```yaml
> IfNotPresent
> ```

Kubernetes imagePullPolicy on Deployment.
#### **livenessProbeImage.registry** ~ `string`

Target image registry. This value is prepended to the target image repository, if set.  
For example:

```yaml
registry: registry.k8s.io
repository: sig-storage/livenessprobe
```

Deprecated: per-component registry prefix.  
  
If set, this value is *prepended* to the image repository that the chart would otherwise render. This applies both when `image.repository` is set and when the repository is computed from  
`imageRegistry` + `imageNamespace` + `image.name`.  
  
This can produce "double registry" style references such as  
`legacy.example.io/quay.io/jetstack/...`. Prefer using the global  
`imageRegistry`/`imageNamespace` values.

#### **livenessProbeImage.repository** ~ `string`
> Default value:
> ```yaml
> ""
> ```

Full repository override (takes precedence over `imageRegistry`, `imageNamespace`, and `image.name`).  
Example: quay.io/jetstack/cert-manager-csi-driver

#### **livenessProbeImage.name** ~ `string`
> Default value:
> ```yaml
> livenessprobe
> ```

The image name for the liveness probe.  
This is used (together with `imageRegistry` and `imageNamespace`) to construct the full image reference.

#### **livenessProbeImage.tag** ~ `string`

Override the image tag to deploy by setting this variable. If no value is set, the chart's appVersion is used.

#### **livenessProbeImage.digest** ~ `string`

Target image digest. Override any tag, if set.  
For example:

```yaml
digest: sha256:0e072dddd1f7f8fc8909a2ca6f65e76c5f0d2fcfb8be47935ae3457e8bbceb20
```

#### **livenessProbeImage.pullPolicy** ~ `string`
> Default value:
> ```yaml
> IfNotPresent
> ```

Kubernetes imagePullPolicy on Deployment.
#### **app.logLevel** ~ `number`
> Default value:
> ```yaml
> 1
> ```

Verbosity of cert-manager-csi-driver logging.
#### **app.driver.name** ~ `string`
> Default value:
> ```yaml
> csi.cert-manager.io
> ```

Name of the driver to be registered with Kubernetes.
#### **app.driver.useTokenRequest** ~ `bool`
> Default value:
> ```yaml
> false
> ```

If enabled, this uses a CSI token request for creating. CertificateRequests. CertificateRequests are created by mounting the pod's service accounts.
#### **app.driver.continueOnNotReady** ~ `bool`
> Default value:
> ```yaml
> false
> ```

If enabled, allows NodePublishVolume to succeed even when the driver is not yet ready to create certificate request. The volume is mounted immediately and certificate issuance is retried asynchronously.
#### **app.driver.kubernetesAPIQPS** ~ `number`
> Default value:
> ```yaml
> 0
> ```

Indicates the maximum queries-per-second requests to the Kubernetes apiserver.  
A value of 0 uses client-go's default.
#### **app.driver.kubernetesAPIBurst** ~ `number`
> Default value:
> ```yaml
> 0
> ```

The maximum burst queries-per-second of requests sent to the Kubernetes apiserver.  
A value of 0 uses client-go's default.
#### **app.driver.podReadinessGates** ~ `array`
> Default value:
> ```yaml
> []
> ```

Defer certificate issuance until all specified pod readiness gates pass. Each entry has the form "<type>:<value>". Supported types:  
  pod-ip:<family>                   family: any | ipv4 | ipv6  
  pod-condition:<Type>[=<Status>]   Status defaults to True  
  pod-annotation:<key>              annotation key must be present  
All gates must pass (AND semantics). Must be combined with continueOnNotReady: true to avoid blocking NodePublishVolume.  
Examples:  
  - "pod-ip:ipv6"  
  - "pod-condition:NetworkAttached=True"  
  - "pod-annotation:k8s.v1.cni.cncf.io/networks-status"
#### **app.driver.gateBackoff.duration** ~ `string`

Base duration between gate-pending retries. The wait between the first failed gate check and the next attempt.

#### **app.driver.gateBackoff.factor** ~ `number`

Multiplier applied to the previous wait after each failed gate check. Must be >= 1. With factor=1, the wait stays constant at `duration`.

#### **app.driver.gateBackoff.jitter** ~ `number`

Random jitter applied as +/- this fraction of the current wait. Must be in [0, 1]. With jitter=0, retries are deterministic. NOTE: jitter=0 cannot be set via this chart (the template only renders the flag when truthy, so 0 is indistinguishable from unset here); use --gate-backoff-jitter=0 directly on the binary if you need this.

#### **app.driver.gateBackoff.cap** ~ `string`

Upper bound on the wait between gate-pending retries; the exponential growth from `factor` is capped here. Must be 0 (uncapped) or >=  
`duration`. NOTE: cap=0 (uncapped) cannot be set via this chart (the  
template only renders the flag when truthy, so 0 is indistinguishable from unset here); use --gate-backoff-cap=0 directly on the binary if you need this.

#### **app.driver.gateBackoff** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Backoff applied between gate-pending retries (i.e. when ReadyToRequest reports a readiness gate is not yet met). Distinct from csi-lib's renewal backoff, which protects against signer failures and is left at csi-lib's defaults. Leave *all* four fields above commented out to defer entirely to csi-lib's own GateBackoffConfig defaults instead of pinning to a copy of them here.  
  
NOTE this is all-or-nothing, not per-field: uncommenting *any one* field above pins all four fields (including any left commented out, which fall back to the CLI's own defaults, not csi-lib's) to the CLI's current values for the driver's lifetime. Only set a field here to intentionally override csi-lib's tuning for a slower or faster gate-resolution profile; be aware that doing so also freezes the other three fields at today's CLI defaults even if csi-lib's own defaults change in a future release.
#### **app.driver.csiDataDir** ~ `string`
> Default value:
> ```yaml
> /tmp/cert-manager-csi-driver
> ```

Configures the hostPath directory that the driver writes and mounts volumes from.
#### **app.livenessProbe.port** ~ `number`
> Default value:
> ```yaml
> 9809
> ```

The port that will expose the liveness of the csi-driver.
#### **app.kubeletRootDir** ~ `string`
> Default value:
> ```yaml
> /var/lib/kubelet
> ```

Overrides the path to root kubelet directory in case of a non-standard Kubernetes install.
#### **daemonSetAnnotations** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Optional additional annotations to add to the csi-driver DaemonSet.
#### **podAnnotations** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Optional additional annotations to add to the csi-driver pods.
#### **podLabels** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Optional additional labels to add to the csi-driver pods.
#### **resources** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Kubernetes pod resources requests/limits for cert-manager-csi-driver.  
  
For example:

```yaml
resources:
  limits:
    cpu: 100m
    memory: 128Mi
  requests:
    cpu: 100m
    memory: 128Mi
```
#### **nodeSelector** ~ `object`
> Default value:
> ```yaml
> kubernetes.io/os: linux
> ```

Kubernetes node selector: node labels for pod assignment.

#### **affinity** ~ `object`
> Default value:
> ```yaml
> {}
> ```

Kubernetes affinity: constraints for pod assignment.  
  
For example:

```yaml
affinity:
  nodeAffinity:
   requiredDuringSchedulingIgnoredDuringExecution:
     nodeSelectorTerms:
     - matchExpressions:
       - key: foo.bar.com/role
         operator: In
         values:
         - master
```
#### **tolerations** ~ `array`
> Default value:
> ```yaml
> []
> ```

Kubernetes pod tolerations for cert-manager-csi-driver.  
  
For example:

```yaml
tolerations:
- operator: "Exists"
```
#### **priorityClassName** ~ `string`
> Default value:
> ```yaml
> ""
> ```

Optional priority class to be used for the csi-driver pods.
#### **hostNetwork** ~ `bool`
> Default value:
> ```yaml
> false
> ```

Configure the host network setting for the csi-driver pods. SECURITY WARNING: When set to true, pods will use the host's network namespace, which grants access to all host network interfaces and allows binding to any port. Ensure this aligns with your security requirements before enabling.  
  
Use case: In some CNI configurations (e.g., Cilium), enabling hostNetwork allows the CSI driver to start before the CNI is ready, reducing pod scheduling delays.  
  
Note: When using hostNetwork, ensure ports for liveness probe and metrics (if enabled) do not conflict with other services on your nodes.
#### **openshift.securityContextConstraint.enabled** ~ `boolean,string,null`
> Default value:
> ```yaml
> detect
> ```

Include RBAC to allow the DaemonSet to "use" the specified  
SecurityContextConstraints.  
  
This value can either be a boolean true or false, or the string "detect". If set to "detect" then the securityContextConstraint is automatically enabled for openshift installs.

#### **openshift.securityContextConstraint.name** ~ `string`
> Default value:
> ```yaml
> privileged
> ```

Name of the SecurityContextConstraints to create RBAC for.

<!-- /AUTO-GENERATED -->